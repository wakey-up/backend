require('dotenv').config();
const Hapi = require('@hapi/hapi');
const Jwt = require('@hapi/jwt');
const userRoutes = require('./api/users/routes');
const jwtStrategy = require('./auth/jwt');

const init = async () => {
  const server = Hapi.server({
    port: 3000,
    host: 'localhost',
    route: {
        cors: {
            origin: ['*'],
        }
    }
  });

  await server.register(Jwt);
  jwtStrategy(server);

  server.route(userRoutes);

  await server.start();
  console.log(`🚀 Server jalan di ${server.info.uri}`);
};

init();
