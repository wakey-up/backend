const users = require('../../models/users');
const Jwt = require('@hapi/jwt');
const bcrypt = require('bcrypt');

module.exports = {
  register: async (request, h) => {
    try {
      const { username, password } = request.payload;

      if (!username || !password) {
        return h.response({ message: 'Username dan password wajib diisi' }).code(400);
      }

      const existingUser = users.findByUsername(username);
      if (existingUser) {
        return h.response({ message: 'Username sudah digunakan' }).code(400);
      }

      const hashedPassword = await bcrypt.hash(password, 10);
      await users.add({ username, password: hashedPassword });

      console.log(`✅ User "${username}" berhasil terdaftar`);
      return h.response({ message: 'Registrasi berhasil' }).code(201);
    } catch (err) {
      console.error('❌ Error di register:', err);
      return h.response({ message: 'Server error saat register' }).code(500);
    }
  },

  login: async (request, h) => {
    try {
      const { username, password } = request.payload;

      if (!username || !password) {
        return h.response({ message: 'Username dan password wajib diisi' }).code(400);
      }

      const user = users.findByUsername(username);

      console.log('🔍 Login request:', { username });
      console.log('📦 User ditemukan:', !!user);

      if (!user) {
        return h.response({ message: 'User tidak ditemukan' }).code(401);
      }

      const valid = await bcrypt.compare(password, user.password);
      console.log('🔐 Password valid:', valid);

      if (!valid) {
        return h.response({ message: 'Password salah' }).code(401);
      }

      const token = Jwt.token.generate(
        { id: user.id, username: user.username },
        {
          key: process.env.JWT_SECRET,
          algorithm: 'HS256',
        }
      );

      return h.response({ message: 'Login berhasil', token }).code(200);
    } catch (err) {
      console.error('❌ Error di login:', err);
      return h.response({ message: 'Server error saat login' }).code(500);
    }
  },

  profile: (request, h) => {
    const { user } = request.auth.credentials;
    return { message: 'Ini profil lo', user };
  },
};
