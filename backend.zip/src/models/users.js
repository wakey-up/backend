const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');

const filePath = path.join(__dirname, '../data/users.json');

function readUsers() {
  try {
    if (!fs.existsSync(filePath)) return [];
    const data = fs.readFileSync(filePath, 'utf-8').trim();

    if (data == '') return [];
    return JSON.parse(data);
  } catch (err) {
    console.error('❌ Error saat baca users.json:', err.message);
    return [];
  }
}

function writeUsers(users) {
  fs.writeFileSync(filePath, JSON.stringify(users, null, 2));
}

module.exports = {
  getAll() {
    return readUsers();
  },

  add(user) {
    const users = readUsers();
    user.id = users.length ? users[users.length - 1].id + 1 : 1;
    users.push(user);
    writeUsers(users);
  },

  findByUsername(username) {
    const users = readUsers();
    return users.find((u) => u.username === username);
  },

  findById(id) {
    const users = readUsers();
    return users.find((u) => u.id === id);
  },

  async validatePassword(username, inputPassword) {
    const user = this.findByUsername(username);
    if (!user) return false;
    try {
      const match = await bcrypt.compare(inputPassword, user.password);
      return match;
    } catch (err) {
      console.error('❌ Gagal validasi password:', err.message);
      return false;
    }
  }
};
